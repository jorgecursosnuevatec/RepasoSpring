package com.jgr.microservicio.gateway.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviciosGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
