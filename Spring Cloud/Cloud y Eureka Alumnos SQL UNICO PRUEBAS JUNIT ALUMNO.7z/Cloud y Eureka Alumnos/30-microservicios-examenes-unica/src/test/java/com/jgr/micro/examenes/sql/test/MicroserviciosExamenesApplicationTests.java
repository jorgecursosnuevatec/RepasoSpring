package com.jgr.micro.examenes.sql.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviciosExamenesApplicationTests {

	@Test
	void contextLoads() {
	}

}
