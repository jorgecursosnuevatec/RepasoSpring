package com.jgr.servicio.curso.sql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationCursoTests {

	@Test
	void contextLoads() {
	}

}
