package com.jgr.servicio.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationGatewayTests {

	@Test
	void contextLoads() {
	}

}
