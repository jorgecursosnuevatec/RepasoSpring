package com.jgr.servicio.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationEurekaTests {

	@Test
	void contextLoads() {
	}

}
